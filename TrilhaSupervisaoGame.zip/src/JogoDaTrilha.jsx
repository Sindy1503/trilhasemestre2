import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

const casas = [
  "Início da Jornada",
  "Planejamento Pedagógico",
  "Acompanhamento de Aprendizagens",
  "Formação Continuada",
  "Feedback a Professores",
  "Escuta Ativa",
  "Visita em Sala de Aula",
  "Reunião com Família",
  "Parada Pedagógica",
  "Replanejamento",
  "Registro e Documentação",
  "Compartilhando Boas Práticas",
  "Superando Desafios",
  "Supervisão que Transforma"
];

const desafios = {
  "Planejamento Pedagógico": "Como você organiza o planejamento com os professores?",
  "Acompanhamento de Aprendizagens": "Que instrumentos você utiliza para acompanhar a aprendizagem?",
  "Formação Continuada": "Compartilhe uma experiência formativa marcante.",
  "Feedback a Professores": "Como dar feedbacks construtivos?",
  "Escuta Ativa": "Qual o papel da escuta na supervisão?",
  "Visita em Sala de Aula": "Como tornar a visita pedagógica produtiva?",
  "Reunião com Família": "Como envolver as famílias nas ações escolares?",
  "Parada Pedagógica": "Quais temas priorizar na parada pedagógica?",
  "Replanejamento": "Como apoiar o replanejamento com base nas evidências?",
  "Registro e Documentação": "Por que registrar e como usar essas informações?",
  "Compartilhando Boas Práticas": "Cite uma prática inspiradora da sua escola.",
  "Superando Desafios": "Como você lida com resistências e dificuldades?"
};

export default function JogoDaTrilha() {
  const [posicao, setPosicao] = useState(0);
  const [mensagem, setMensagem] = useState("");
  const [dado, setDado] = useState(null);

  useEffect(() => {
    const audio = new Audio("https://actions.google.com/sounds/v1/cartoon/clang_and_wobble.ogg");
    if (dado !== null) {
      audio.play();
    }
  }, [dado]);

  const jogarDado = () => {
    const resultado = Math.floor(Math.random() * 3) + 1;
    setDado(resultado);
    const novaPosicao = Math.min(posicao + resultado, casas.length - 1);
    setPosicao(novaPosicao);
    const casaAtual = casas[novaPosicao];
    setMensagem(
      desafios[casaAtual] ||
        (novaPosicao === casas.length - 1
          ? "🎉 Parabéns! Você concluiu a trilha da supervisão! 🎓"
          : "👏 Parabéns por avançar na trilha!")
    );
  };

  return (
    <div className="p-4 max-w-5xl mx-auto space-y-6">
      <motion.h1
        className="text-3xl font-bold text-center text-blue-700"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        🎯 Jogo da Trilha da Supervisão
      </motion.h1>

      <motion.div
        className="grid grid-cols-4 md:grid-cols-7 gap-2"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2, duration: 0.5 }}
      >
        {casas.map((casa, index) => (
          <motion.div
            key={index}
            className={\`relative p-3 border rounded-md text-center text-xs md:text-sm shadow-sm transition-all duration-300 \${index === posicao ? "bg-yellow-300 border-yellow-500 font-bold" : "bg-white text-gray-800"}\`}
            whileHover={{ scale: 1.05 }}
          >
            {index === posicao && (
              <motion.div
                className="absolute -top-5 left-1/2 -translate-x-1/2 text-lg"
                animate={{ y: [0, -5, 0] }}
                transition={{ repeat: Infinity, duration: 1 }}
              >
                🧍‍♂️
              </motion.div>
            )}
            {index + 1}. {casa}
          </motion.div>
        ))}
      </motion.div>

      {dado && (
        <motion.div
          className="text-center text-xl font-semibold text-purple-600"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", stiffness: 200 }}
        >
          🎲 Você tirou: {dado}
        </motion.div>
      )}

      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }}>
        <Card>
          <CardContent className="p-4">
            <p className="text-md text-gray-800 text-center">{mensagem}</p>
          </CardContent>
        </Card>
      </motion.div>

      <motion.div
        className="flex justify-center"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.95 }}
      >
        <Button onClick={jogarDado} className="text-lg px-6 py-2">
          Jogar o dado 🎲
        </Button>
      </motion.div>
    </div>
  );
}